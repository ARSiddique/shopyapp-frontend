// Copyright 2020, the Chromium project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';

void runInstanceTests() {
  group(
    '$FirebaseFirestore.instance',
    () {
      late FirebaseFirestore firestore;

      setUpAll(() async {
        firestore = FirebaseFirestore.instance;
      });

      testWidgets(
        'snapshotsInSync()',
        (_) async {
          DocumentReference<Map<String, dynamic>> documentReference =
              firestore.doc('flutter-tests/insync');

          // Ensure deleted
          await documentReference.delete();

          StreamController controller = StreamController();
          StreamSubscription insync;
          StreamSubscription snapshots;

          int inSyncCount = 0;

          insync = firestore.snapshotsInSync().listen((_) {
            controller.add('insync=$inSyncCount');
            inSyncCount++;
          });

          snapshots = documentReference.snapshots().listen((ds) {
            controller.add('snapshot-exists=${ds.exists}');
          });

          // Allow the snapshots to trigger...
          await Future.delayed(const Duration(seconds: 1));

          await documentReference.set({'foo': 'bar'});

          await expectLater(
            controller.stream,
            emitsInOrder([
              'insync=0', // No other snapshots
              'snapshot-exists=false',
              'insync=1',
              'snapshot-exists=true',
              'insync=2',
            ]),
          );

          await controller.close();
          await insync.cancel();
          await snapshots.cancel();
        },
        skip: kIsWeb,
      );

      testWidgets(
        'enableNetwork()',
        (_) async {
          // Write some data while online
          await firestore.enableNetwork();
          DocumentReference<Map<String, dynamic>> documentReference =
              firestore.doc('flutter-tests/enable-network');
          await documentReference.set({'foo': 'bar'});

          // Disable the network
          await firestore.disableNetwork();

          StreamController controller = StreamController();

          // Set some data while offline
          // ignore: unawaited_futures
          documentReference.set({'foo': 'baz'}).then((_) async {
            // Only when back online will this trigger
            controller.add(true);
          });

          // Go back online
          await firestore.enableNetwork();

          await expectLater(controller.stream, emits(true));
          await controller.close();
        },
        skip: kIsWeb,
      );

      testWidgets(
        'disableNetwork()',
        (_) async {
          // Write some data while online
          await firestore.enableNetwork();
          DocumentReference<Map<String, dynamic>> documentReference =
              firestore.doc('flutter-tests/disable-network');
          await documentReference.set({'foo': 'bar'});

          // Disable the network
          await firestore.disableNetwork();

          // Get data from cache
          DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
              await documentReference.get();
          expect(documentSnapshot.metadata.isFromCache, isTrue);
          expect(documentSnapshot.data()!['foo'], equals('bar'));

          // Go back online once test complete
          await firestore.enableNetwork();
        },
        skip: kIsWeb,
      );

      testWidgets(
        'waitForPendingWrites()',
        (_) async {
          await firestore.waitForPendingWrites();
        },
        skip: kIsWeb,
      );

      testWidgets(
        'terminate() / clearPersistence()',
        (_) async {
          // Since the firestore instance has already been used,
          // calling `clearPersistence` will throw a native error.
          // We first check it does throw as expected, then terminate
          // the instance, and then check whether clearing succeeds.
          try {
            await firestore.clearPersistence();
            fail('Should have thrown');
          } on FirebaseException catch (e) {
            expect(e.code, equals('failed-precondition'));
          } catch (e) {
            fail('$e');
          }

          await firestore.terminate();
          await firestore.clearPersistence();
        },
        skip: kIsWeb || defaultTargetPlatform == TargetPlatform.windows,
      );

      testWidgets(
        'setIndexConfiguration()',
        (_) async {
          Index index1 = Index(
            collectionGroup: 'bar',
            queryScope: QueryScope.collectionGroup,
            fields: [
              IndexField(
                fieldPath: 'fieldPath',
                order: Order.ascending,
                arrayConfig: ArrayConfig.contains,
              ),
            ],
          );

          Index index2 = Index(
            collectionGroup: 'baz',
            queryScope: QueryScope.collection,
            fields: [
              IndexField(
                fieldPath: 'foo',
                arrayConfig: ArrayConfig.contains,
              ),
              IndexField(
                fieldPath: 'bar',
                order: Order.descending,
                arrayConfig: ArrayConfig.contains,
              ),
              IndexField(
                fieldPath: 'baz',
                order: Order.descending,
                arrayConfig: ArrayConfig.contains,
              ),
            ],
          );

          FieldOverrides fieldOverride1 = FieldOverrides(
            fieldPath: 'fieldPath',
            indexes: [
              FieldOverrideIndex(
                queryScope: 'foo',
                order: Order.ascending,
                arrayConfig: ArrayConfig.contains,
              ),
              FieldOverrideIndex(
                queryScope: 'bar',
                order: Order.descending,
                arrayConfig: ArrayConfig.contains,
              ),
              FieldOverrideIndex(
                queryScope: 'baz',
                order: Order.descending,
              ),
            ],
            collectionGroup: 'bar',
          );
          FieldOverrides fieldOverride2 = FieldOverrides(
            fieldPath: 'anotherField',
            indexes: [
              FieldOverrideIndex(
                queryScope: 'foo',
                order: Order.ascending,
                arrayConfig: ArrayConfig.contains,
              ),
              FieldOverrideIndex(
                queryScope: 'bar',
                order: Order.descending,
                arrayConfig: ArrayConfig.contains,
              ),
              FieldOverrideIndex(
                queryScope: 'baz',
                order: Order.descending,
              ),
            ],
            collectionGroup: 'collectiongroup',
          );
          // ignore_for_file: deprecated_member_use
          await firestore.setIndexConfiguration(
            indexes: [index1, index2],
            fieldOverrides: [fieldOverride1, fieldOverride2],
          );
        },
        skip: defaultTargetPlatform == TargetPlatform.windows,
      );

      testWidgets(
        'setIndexConfigurationFromJSON()',
        (_) async {
          final json = jsonEncode({
            'indexes': [
              {
                'collectionGroup': 'posts',
                'queryScope': 'COLLECTION',
                'fields': [
                  {'fieldPath': 'author', 'arrayConfig': 'CONTAINS'},
                  {'fieldPath': 'timestamp', 'order': 'DESCENDING'},
                ],
              }
            ],
            'fieldOverrides': [
              {
                'collectionGroup': 'posts',
                'fieldPath': 'myBigMapField',
                'indexes': [],
              }
            ],
          });

          await firestore.setIndexConfigurationFromJSON(json);
        },
        skip: defaultTargetPlatform == TargetPlatform.windows,
      );

      testWidgets('setLoggingEnabled should resolve without issue',
          (widgetTester) async {
        await FirebaseFirestore.setLoggingEnabled(true);
        await FirebaseFirestore.setLoggingEnabled(false);
      });

      testWidgets(
          'Settings() - `persistenceEnabled` & `cacheSizeBytes` with acceptable number',
          (widgetTester) async {
        FirebaseFirestore.instance.settings =
            const Settings(persistenceEnabled: true, cacheSizeBytes: 10000000);
        // Used to trigger settings
        await FirebaseFirestore.instance
            .collection('flutter-tests')
            .doc('new-doc')
            .set(
          {'some': 'data'},
        );
      });

      testWidgets(
          'Settings() - `persistenceEnabled` & `cacheSizeBytes` with `Settings.CACHE_SIZE_UNLIMITED`',
          (widgetTester) async {
        FirebaseFirestore.instance.settings = const Settings(
          persistenceEnabled: true,
          cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
        );
        // Used to trigger settings
        await FirebaseFirestore.instance
            .collection('flutter-tests')
            .doc('new-doc')
            .set(
          {'some': 'data'},
        );
      });

      testWidgets(
          'Settings() - `persistenceEnabled` & without `cacheSizeBytes`',
          (widgetTester) async {
        FirebaseFirestore.instance.settings =
            const Settings(persistenceEnabled: true);
        // Used to trigger settings
        await FirebaseFirestore.instance
            .collection('flutter-tests')
            .doc('new-doc')
            .set(
          {'some': 'data'},
        );
      });
    },
  );
}
